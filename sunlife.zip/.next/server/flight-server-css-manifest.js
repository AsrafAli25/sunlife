self.__RSC_CSS_MANIFEST={
  "__entry_css_mods__": {
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\about\\page": [
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\globals.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\themes\\bootstrap4-light-blue\\theme.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\primereact.min.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeicons\\primeicons.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeflex\\primeflex.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\components\\footer\\footer.css"
    ],
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\page": [
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\globals.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\themes\\bootstrap4-light-blue\\theme.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\primereact.min.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeicons\\primeicons.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeflex\\primeflex.css",
      "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\components\\footer\\footer.css"
    ]
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\layout.js": [
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\globals.css",
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\themes\\bootstrap4-light-blue\\theme.css",
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\primereact.min.css",
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeicons\\primeicons.css",
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeflex\\primeflex.css",
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\components\\footer\\footer.css"
  ],
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\page.js": [
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\page.module.css"
  ]
}