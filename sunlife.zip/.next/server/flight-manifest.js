self.__RSC_MANIFEST={
  "__ssr_module_mapping__": {
    "(app-client)/./src/app/layout.js": {
      "": {
        "id": "(sc_client)/./src/app/layout.js",
        "name": "",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./src/app/layout.js",
        "name": "*",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./src/app/layout.js",
        "name": "default",
        "chunks": [
          "app/layout:app/layout"
        ],
        "async": false
      }
    },
    "(app-client)/./src/app/about/page.js": {
      "": {
        "id": "(sc_client)/./src/app/about/page.js",
        "name": "",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./src/app/about/page.js",
        "name": "*",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./src/app/about/page.js",
        "name": "default",
        "chunks": [
          "app/about/page:app/about/page"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:app-client-internals"
        ],
        "async": false
      }
    },
    "(app-client)/./src/app/page.js": {
      "": {
        "id": "(sc_client)/./src/app/page.js",
        "name": "",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "*": {
        "id": "(sc_client)/./src/app/page.js",
        "name": "*",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./src/app/page.js",
        "name": "default",
        "chunks": [
          "app/page:app/page"
        ],
        "async": false
      }
    }
  },
  "__edge_ssr_module_mapping__": {},
  "__entry_css_files__": {
    "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\layout": [
      "static/css/app/layout.css"
    ]
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeflex\\primeflex.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primeicons\\primeicons.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\primereact.min.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\primereact\\resources\\themes\\bootstrap4-light-blue\\theme.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\components\\footer\\footer.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\globals.css": {
    "default": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\layout.js": {
    "": {
      "id": "(app-client)/./src/app/layout.js",
      "name": "",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./src/app/layout.js",
      "name": "*",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./src/app/layout.js",
      "name": "default",
      "chunks": [
        "app/layout:app/layout"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\about\\page.js": {
    "": {
      "id": "(app-client)/./src/app/about/page.js",
      "name": "",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./src/app/about/page.js",
      "name": "*",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./src/app/about/page.js",
      "name": "default",
      "chunks": [
        "app/about/page:app/about/page"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\next\\dist\\client\\components\\app-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
    "": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:app-client-internals"
      ],
      "async": false
    }
  },
  "D:\\Asraf\\next_js\\project\\trying\\sunlife\\src\\app\\page.js": {
    "": {
      "id": "(app-client)/./src/app/page.js",
      "name": "",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "*": {
      "id": "(app-client)/./src/app/page.js",
      "name": "*",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    },
    "default": {
      "id": "(app-client)/./src/app/page.js",
      "name": "default",
      "chunks": [
        "app/page:app/page"
      ],
      "async": false
    }
  }
}